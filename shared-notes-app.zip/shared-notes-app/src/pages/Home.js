import React, { useState } from "react";
import NotesList from "../components/NotesList";
import NoteEditor from "../components/NoteEditor";
import "../styles/home.css";

const Home = () => {
  const [tasks, setTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [newTask, setNewTask] = useState({ title: "", content: "" });

  const addTask = () => {
    if (!newTask.title || !newTask.content) return;
    const task = {
      id: Date.now(),
      title: newTask.title,
      content: newTask.content,
      pinned: false,
    };
    setTasks([task, ...tasks]);
    setNewTask({ title: "", content: "" });
  };

  return (
    <div className="home">
      <div className="sidebar">
        <h3>Tasks</h3>
        <NotesList tasks={tasks} setTasks={setTasks} setSelectedTask={setSelectedTask} />
      </div>
      <div className="editor-area">
        <NoteEditor
          selectedTask={selectedTask}
          newTask={newTask}
          setNewTask={setNewTask}
          addTask={addTask}
        />
      </div>
    </div>
  );
};

export default Home;
