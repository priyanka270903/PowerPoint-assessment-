const Quiz = require('../models/Quiz');

// Generate a new quiz
exports.generateQuiz = async (req, res) => {
    const { grade, subject, totalQuestions, maxScore, difficulty, questions } = req.body;
    try {
        const quiz = new Quiz({ 
            grade, 
            subject, 
            totalQuestions, 
            maxScore, 
            difficulty,
            questions
        });
        await quiz.save();
        res.status(201).json(quiz);
    } catch (err) {
        res.status(500).json({ message: 'Error generating quiz' });
    }
};

// Submit quiz responses
exports.submitQuiz = async (req, res) => {
    const { quizId, responses } = req.body;
    const studentId = req.userId; // Assuming `req.userId` is set by authentication middleware

    try {
        const quiz = await Quiz.findById(quizId);
        if (!quiz) return res.status(404).json({ message: 'Quiz not found' });

        let totalScore = 0;
        const responseDetails = responses.map(response => {
            const question = quiz.questions.find(q => q.questionId === response.questionId);
            if (!question) return null; // Ensure question exists
            const isCorrect = question.correctAnswer === response.userResponse;
            const score = isCorrect ? question.score : 0;
            totalScore += score;

            return {
                questionId: response.questionId,
                userResponse: response.userResponse,
                score
            };
        }).filter(response => response !== null); // Filter out null responses

        // Add the student's responses to the quiz
        quiz.studentResponses.push({
            studentId,
            responses: responseDetails,
            totalScore
        });

        // Save the quiz with student responses
        await quiz.save();

        res.json({
            message: 'Quiz submitted successfully',
            totalScore,
            responses: responseDetails
        });
    } catch (err) {
        res.status(500).json({ message: 'Error submitting quiz' });
    }
};

// Get quiz history based on filters
exports.getQuizHistory = async (req, res) => {
    const { grade, subject, from, to } = req.query;
    try {
        const filters = {};
        if (grade) filters.grade = grade;
        if (subject) filters.subject = subject;
        if (from && to) {
            filters.completedDate = { $gte: new Date(from), $lte: new Date(to) };
        }

        // Get quizzes that match filters
        const quizzes = await Quiz.find(filters)
            .populate('studentResponses.studentId') // Optionally populate user data
            .exec();

        res.json(quizzes);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching quiz history' });
    }
};
