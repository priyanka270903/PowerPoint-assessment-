import React from "react";
import { FaThumbtack, FaTrashAlt } from "react-icons/fa";
import "../styles/notesList.css";

const NotesList = ({ tasks, setTasks, setSelectedTask }) => {
  const togglePin = (id) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === id ? { ...task, pinned: !task.pinned } : task
      )
    );
  };

  const deleteTask = (id) => {
    setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id));
  };

  const selectTask = (task) => {
    setSelectedTask(task);
  };

  const sortedTasks = [...tasks].sort((a, b) => b.pinned - a.pinned);

  return (
    <div className="notes-list">
      <ul>
        {sortedTasks.map((task) => (
          <li
            key={task.id}
            className={`task-item ${task.pinned ? "pinned" : ""}`}
            onClick={() => selectTask(task)}
          >
            <div className="task-info">
              <span>{task.title}</span>
            </div>
            <div className="task-actions">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  togglePin(task.id);
                }}
                className="pin-btn"
              >
                <FaThumbtack />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteTask(task.id);
                }}
                className="delete-btn"
              >
                <FaTrashAlt />
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NotesList;
