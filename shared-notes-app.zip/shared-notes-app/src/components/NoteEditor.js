import React, { useEffect, useRef, useState } from "react";
import "../styles/noteEditor.css";

const NoteEditor = ({ selectedTask, newTask, setNewTask, addTask, updateTask }) => {
  const editorRef = useRef(null);
  const popupEditorRef = useRef(null);
  const [showPopup, setShowPopup] = useState(false);
  const [popupTask, setPopupTask] = useState(null);

  // Handle editor input (new task)
  const handleEditorInput = () => {
    if (editorRef.current) {
      const content = editorRef.current.innerHTML;
      setNewTask((prev) => ({ ...prev, content }));
    }
  };

  // Handle popup editor input (editing task)
  const handlePopupEditorInput = () => {
    if (popupEditorRef.current) {
      const content = popupEditorRef.current.innerHTML;
      setPopupTask((prev) => ({ ...prev, content }));
    }
  };

  // Handle title input for new task
  const handleInput = (e) => {
    const { name, value } = e.target;
    setNewTask((prev) => ({ ...prev, [name]: value }));
  };

  // Handle title input for popup task
  const handlePopupInput = (e) => {
    const { name, value } = e.target;
    setPopupTask((prev) => ({ ...prev, [name]: value }));
  };

  // Show popup if a task is selected
  useEffect(() => {
    if (selectedTask) {
      setPopupTask({ ...selectedTask });
      setShowPopup(true);
    }
  }, [selectedTask]);

  // Sync the content of the editor with the newTask content
  useEffect(() => {
    if (editorRef.current && newTask.content !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = newTask.content || "";
    }
  }, [newTask.content]);

  // Sync the content of the popup editor
  useEffect(() => {
    if (popupEditorRef.current && popupTask?.content !== popupEditorRef.current.innerHTML) {
      popupEditorRef.current.innerHTML = popupTask?.content || "";
    }
  }, [popupTask?.content]);

  // Save changes in the popup and update the task
  const saveChanges = () => {
    if (popupTask && updateTask) {
      console.log("Saving task: ", popupTask); // Debugging: check if popupTask is valid
      updateTask(popupTask); // Call the updateTask function passed as prop
      setShowPopup(false); // Close the popup
    } else {
      console.error("updateTask or popupTask is not defined");
    }
  };

  return (
    <div className="note-editor">
      {/* New task editor */}
      <input
        type="text"
        name="title"
        placeholder="Note Title"
        value={newTask.title}
        onChange={handleInput}
        className="title-input"
      />
      <div className="editor-toolbar">
        <button onClick={() => document.execCommand("bold")} title="Bold">
          <b>B</b>
        </button>
        <button onClick={() => document.execCommand("italic")} title="Italic">
          <i>I</i>
        </button>
        <button onClick={() => document.execCommand("underline")} title="Underline">
          <u>U</u>
        </button>
      </div>
      <div
        className="editor"
        contentEditable="true"
        ref={editorRef}
        onInput={handleEditorInput}
        suppressContentEditableWarning={true}
      ></div>
      <button onClick={addTask} className="add-note-btn">
        Add Note
      </button>

      {/* Popup editor for editing selected task */}
      {showPopup && popupTask && (
        <div className="popup-overlay">
          <div className="popup-content">
            <div className="popup-header">
              <h2>Edit Task</h2>
            </div>
            <div className="popup-body">
              <input
                type="text"
                name="title"
                value={popupTask.title}
                onChange={handlePopupInput}
                className="popup-title-input"
                placeholder="Popup Note Title"
              />
              <div className="editor-toolbar">
                <button onClick={() => document.execCommand("bold")} title="Bold">
                  <b>B</b>
                </button>
                <button onClick={() => document.execCommand("italic")} title="Italic">
                  <i>I</i>
                </button>
                <button onClick={() => document.execCommand("underline")} title="Underline">
                  <u>U</u>
                </button>
              </div>
              <div
                className="popup-editor"
                contentEditable="true"
                ref={popupEditorRef}
                onInput={handlePopupEditorInput}
                suppressContentEditableWarning={true}
              ></div>
            </div>
            <div className="popup-footer">
              <button className="save-popup-btn" onClick={saveChanges}>
                Save & Close
              </button>
              <button className="cancel-popup-btn" onClick={() => setShowPopup(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NoteEditor;
