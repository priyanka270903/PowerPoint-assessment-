const mongoose = require('mongoose');

const quizSchema = new mongoose.Schema({
    grade: {
        type: Number,
        required: true
    },
    subject: {
        type: String,
        required: true
    },
    totalQuestions: {
        type: Number,
        required: true
    },
    maxScore: {
        type: Number,
        required: true
    },
    difficulty: {
        type: String,
        required: true
    },
    questions: [{
        questionId: {
            type: String,
            required: true
        },
        questionText: {
            type: String,
            required: true
        },
        correctAnswer: {
            type: String,
            required: true
        },
        score: {
            type: Number,
            required: true
        }
    }],
    studentResponses: [{
        studentId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true
        },
        responses: [{
            questionId: {
                type: String,
                required: true
            },
            userResponse: {
                type: String,
                required: true
            },
            score: {
                type: Number,
                default: 0
            }
        }],
        totalScore: {
            type: Number,
            default: 0
        },
        completedDate: {
            type: Date,
            default: Date.now
        }
    }]
});

module.exports = mongoose.model('Quiz', quizSchema);
