const fs = require('fs');
const path = require('path');

// Define the directory structure
const structure = {
  'src': {
    'components': ['Toolbar.js', 'NotesList.js', 'NoteEditor.js'],
    'pages': ['Home.js'],
    'hooks': ['useLocalStorage.js'],
    'utils': ['textUtils.js'],
    'styles': [],
    'App.js': '',
    'index.js': ''
  }
};

// Helper function to create directories and files
const createStructure = (basePath, structure) => {
  for (const [key, value] of Object.entries(structure)) {
    const currentPath = path.join(basePath, key);

    if (Array.isArray(value)) {
      // Create directory and files inside it
      if (!fs.existsSync(currentPath)) {
        fs.mkdirSync(currentPath, { recursive: true });
      }
      value.forEach(file => {
        const filePath = path.join(currentPath, file);
        if (!fs.existsSync(filePath)) {
          fs.writeFileSync(filePath, '', 'utf8'); // Create an empty file
          console.log(`Created file: ${filePath}`);
        }
      });
    } else if (typeof value === 'string' && value === '') {
      // Create a file in the current directory
      if (!fs.existsSync(currentPath)) {
        fs.writeFileSync(currentPath, '', 'utf8'); // Create an empty file
        console.log(`Created file: ${currentPath}`);
      }
    }
  }
};

// Start creating the directory structure under './src'
const baseDir = path.join(__dirname, 'src');
if (!fs.existsSync(baseDir)) {
  fs.mkdirSync(baseDir, { recursive: true });
}

createStructure(baseDir, structure);

console.log('Directory structure has been created.');
