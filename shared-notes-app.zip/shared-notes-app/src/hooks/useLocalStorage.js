import { useState, useEffect } from "react";
import CryptoJS from "crypto-js";

const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(CryptoJS.AES.decrypt(item, "secret-key").toString(CryptoJS.enc.Utf8)) : initialValue;
    } catch (error) {
      return initialValue;
    }
  });

  useEffect(() => {
    const encryptedValue = CryptoJS.AES.encrypt(JSON.stringify(storedValue), "secret-key").toString();
    window.localStorage.setItem(key, encryptedValue);
  }, [key, storedValue]);

  return [storedValue, setStoredValue];
};

export default useLocalStorage;
