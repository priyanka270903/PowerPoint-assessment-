const fs = require('fs');
const path = require('path');

// Function to recursively traverse a directory and write its files and content to a txt file
function writeDirectoryStructureToFile(dirPath, outputFilePath, indent = '') {
  // Check if the directory exists
  if (!fs.existsSync(dirPath)) {
    console.log('Directory does not exist');
    return;
  }

  // Read the content of the directory
  const files = fs.readdirSync(dirPath);

  // Loop through each file in the directory
  files.forEach(file => {
    const fullPath = path.join(dirPath, file); // Get the full file path
    const stats = fs.statSync(fullPath); // Get file stats

    if (stats.isDirectory()) {
      // If it's a directory, recursively process its content
      writeDirectoryStructureToFile(fullPath, outputFilePath, indent + '│   ');
    } else {
      // If it's a file, get its content and write to the output file
      const fileContent = fs.readFileSync(fullPath, 'utf8'); // Read the file content
      const filePath = path.relative(__dirname, fullPath).replace(/\\/g, '/'); // Get the relative file path for better readability
      const contentToWrite = `${filePath} : \n${fileContent}\n\n`;

      // Append the content to the output text file
      fs.appendFileSync(outputFilePath, contentToWrite);
    }
  });
}

// Specify the root directory (change to the path of your `src` folder if needed)
const rootDir = path.join(__dirname, 'src'); // Use `__dirname` to point to the current directory (script location)

// Output file path
const outputFilePath = path.join(__dirname, 'output.txt');

// Clear the output file first (if it exists) to avoid appending to an old file
fs.writeFileSync(outputFilePath, '');

// Print the directory structure and write file contents to the output file
console.log('Writing directory structure and file contents to output.txt...');
writeDirectoryStructureToFile(rootDir, outputFilePath);

console.log('Process completed!');
