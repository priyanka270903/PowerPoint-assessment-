const fs = require('fs');
const path = require('path');

// Function to recursively traverse a directory and print its structure
function printDirectoryStructure(dirPath, indent = '') {
  // Check if the directory exists
  if (!fs.existsSync(dirPath)) {
    console.log('Directory does not exist');
    return;
  }

  // Read the content of the directory
  const files = fs.readdirSync(dirPath);

  // Loop through each file in the directory
  files.forEach(file => {
    const fullPath = path.join(dirPath, file); // Get the full file path
    const stats = fs.statSync(fullPath); // Get file stats

    if (stats.isDirectory()) {
      // If it's a directory, print the directory name with an arrow, then recursively print its content
      console.log(`${indent}├── ${file}/`);
      printDirectoryStructure(fullPath, indent + '│   '); // Recursively print contents
    } else {
      // If it's a file, just print the file name
      console.log(`${indent}├── ${file}`);
    }
  });
}

// Specify the root directory (change to the path of your `src` folder if needed)
const rootDir = path.join(__dirname, 'src'); // Use `__dirname` to point to the current directory (script location)

// Print the directory structure starting from the `src` folder
console.log('Directory structure:');
printDirectoryStructure(rootDir, ''); // Call the function with an empty initial indent
