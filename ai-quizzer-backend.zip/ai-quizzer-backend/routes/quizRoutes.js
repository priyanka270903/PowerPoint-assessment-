const express = require('express');
const { generateQuiz, submitQuiz, getQuizHistory } = require('../controllers/quizController');
const { authMiddleware } = require('../middleware/authMiddleware');
const router = express.Router();

// Route to generate a quiz
router.post('/generate', authMiddleware, generateQuiz);

// Route to submit quiz responses
router.post('/submit', authMiddleware, submitQuiz);

// Route to fetch quiz history with filters
router.get('/history', authMiddleware, getQuizHistory);

module.exports = router;
