import React from "react";
import { FaBold, FaItalic, FaUnderline } from "react-icons/fa";

const Toolbar = ({ onCommand }) => {
  return (
    <div className="toolbar">
      <button onClick={() => onCommand("bold")}>
        <FaBold />
      </button>
      <button onClick={() => onCommand("italic")}>
        <FaItalic />
      </button>
      <button onClick={() => onCommand("underline")}>
        <FaUnderline />
      </button>
      <button onClick={() => onCommand("justifyLeft")}>Left</button>
      <button onClick={() => onCommand("justifyCenter")}>Center</button>
      <button onClick={() => onCommand("justifyRight")}>Right</button>
      <select onChange={(e) => onCommand("fontSize", e.target.value)}>
        <option value="3">Normal</option>
        <option value="5">Large</option>
        <option value="7">Extra Large</option>
      </select>
    </div>
  );
};

export default Toolbar;
